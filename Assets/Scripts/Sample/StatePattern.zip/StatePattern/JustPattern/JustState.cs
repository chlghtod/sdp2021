﻿// 상태 인터페이스 클래스
public interface JustState
{
    void Action();
};
